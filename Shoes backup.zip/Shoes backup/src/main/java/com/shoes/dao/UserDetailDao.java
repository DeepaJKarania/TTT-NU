package com.shoes.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shoes.model.UserCredential;
import com.shoes.model.UserDetail;

@Repository
public class UserDetailDao {
	@Autowired
	private SessionFactory sessionFactory;

	public void insert(UserDetail userDetail) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.getTransaction();
		tx.begin();
		
		session.save(userDetail);
//		
//		session.flush();
		tx.commit();
		session.close();
	}

	public void insertcredent(UserCredential userCredential) {
		Session session = sessionFactory.openSession();
		Transaction tx = session.getTransaction();
		tx.begin();
		
		session.save(userCredential);
//		
//		session.flush();
		tx.commit();
		session.close();
	}
	
	public String getAddrByName(String custName) {
		Session ses = sessionFactory.openSession();
		Criteria c= ses.createCriteria(UserDetail.class);
		String result=((UserDetail)c.add(Restrictions.ilike("custName",custName)).list().get(0)).getAddress();
		return result;
			
		}
		public UserDetail display(String custName)
		{
			Session session = sessionFactory.openSession();
			session.beginTransaction();
		     UserDetail ru=( UserDetail)session.get( UserDetail.class,custName);
			session.getTransaction().commit();
			session.close();
		   return ru;
			
			
		}
}