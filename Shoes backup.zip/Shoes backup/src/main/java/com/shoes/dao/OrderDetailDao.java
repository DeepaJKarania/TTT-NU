package com.shoes.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.shoes.model.*;


@Repository
public class OrderDetailDao {
	@Autowired
	SessionFactory sessionFactory;

	public void saveOrder(OrderDetails o) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(o);
	     ses.getTransaction().commit();
		ses.close();
		
	}
	
	public String getOrderDetail(int oId)
	{
		Session session = sessionFactory.openSession();
		session.beginTransaction();
	    OrderDetails ru=( OrderDetails)session.get( OrderDetails.class,oId);
		session.getTransaction().commit();
		Gson g = new Gson();
	    String data = g.toJson(ru);
		session.close();
	   return data;
		
		
	}
}
