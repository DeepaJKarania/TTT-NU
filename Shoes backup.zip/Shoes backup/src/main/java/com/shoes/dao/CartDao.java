package com.shoes.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.shoes.model.ShopCart;

@Repository
public class CartDao {
	
	@Autowired
	SessionFactory sessionFactory;

	public String saveCart(ShopCart shopCart) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(shopCart);
		Gson g = new Gson();
		String data = g.toJson(g);
		ses.getTransaction().commit();
		ses.close();
		return data;
	}
}
