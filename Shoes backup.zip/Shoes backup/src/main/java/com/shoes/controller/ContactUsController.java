package com.shoes.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shoes.model.Contact;

@Controller
public class ContactUsController {
	
	@RequestMapping(value = "/Contact", method = RequestMethod.GET)  
	public String displayRegister(@ModelAttribute("Contact")Contact contact) { 
    return "Contact"; 
	}
	
	@RequestMapping("/EmailForm")
	public String showEmailForm()
	{	
		
		return "EmailForm";	
	}
	
	@RequestMapping("/Home")
	public String showHome()
	{	
		
		return "Home";	
	}
	
	@RequestMapping("/CartPage")
	public String showCartPage()
	{	
		
		return "CartPage";	
	}
	
		
	@RequestMapping("/DisplayProduct")
	public String showDisplayProduct()
	{
		return "DisplayProduct";
	}
}
