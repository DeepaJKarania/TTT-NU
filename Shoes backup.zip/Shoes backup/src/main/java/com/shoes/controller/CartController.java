
package com.shoes.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shoes.dao.*;
import com.google.gson.Gson;

import com.shoes.model.*;

@Controller
public class CartController {

	@Autowired
	CartDao cartDao;
	@Autowired
	ProductDao proDao;
	@Autowired
	UserDetailDao userObj;
	@Autowired
	OrderDetailDao orderDao;

	@RequestMapping(value = "/addtoCart", method = RequestMethod.GET)
	public ModelAndView viewCart(@RequestParam("pid") int id, HttpSession session) {

		Product p = proDao.getRowById(id);
		ShopCart c = new ShopCart();

		c.setpId(p.getItemID());
		c.setItemName(p.getItemName());
		c.setPrice(p.getPrice());

		ArrayList<ShopCart> li = (ArrayList<ShopCart>) session.getAttribute("mycart");
		li.add(c);
		int size = li.size();
		session.setAttribute("count", size);
		ModelAndView m = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		m.addObject("cartitm", li);
		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(li)));
		return m;

	}

	@RequestMapping(value = "/DelCartItem", method = RequestMethod.GET)
	public ModelAndView DelCartItem(@RequestParam("pid") int id, HttpSession session) {
		ArrayList<ShopCart> ld = (ArrayList<ShopCart>) session.getAttribute("mycart");

		ListIterator<ShopCart> lit = (ListIterator<ShopCart>) ld.listIterator();
		while (lit.hasNext()) {
			ShopCart d = lit.next();
			if (d.getpId() == id) {
				ld.remove(ld.indexOf(d)); // removing data from session List
				break;
			}
		}
		int size = ld.size();
		session.setAttribute("count", size);
		session.setAttribute("mycart", ld); // again added data into session
		ModelAndView mv = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		mv.addObject("cartitm", ld);
		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(ld)));
		return mv;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/OrderConfirmation")
	public String showOrderPage(HttpSession session, Model m) {
		ArrayList<ShopCart> shoList = (ArrayList<ShopCart>)session.getAttribute("mycart");
		Gson g = new Gson();
		String data = g.toJson(shoList);

		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(shoList)));

		System.out.println(shoList);
		
		m.addAttribute("caritem", shoList);
		return "OrderConfirmation";
	}

	@RequestMapping(value = "/BackToCartPage")
	public ModelAndView BackToCartPage(HttpSession session) {
		ArrayList<ShopCart> shoList = (ArrayList<ShopCart>) session.getAttribute("mycart");
		Gson g = new Gson();
		String data = g.toJson(shoList);
		ModelAndView m = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		m.addObject("cart", shoList);

		session.setAttribute("cart", data);
		session.setAttribute("cartitm", shoList);
		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(shoList)));

		return m;

	}

	@RequestMapping(value = "/GoToCart", method = RequestMethod.GET)
	public ModelAndView gotocart(HttpSession session) {

		ArrayList<ShopCart> li = (ArrayList<ShopCart>) session.getAttribute("mycart");
		session.setAttribute("cart", li);
		ModelAndView mv = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		mv.addObject("cartitm", li);
		return mv;

	}

	@RequestMapping(value = "/upDateqty", method = RequestMethod.GET)
	public String updateqty(@RequestParam("qty") int qty, @RequestParam("pid") int pid, HttpSession session, Model m) {

		System.out.println("Quantity:" + qty);
		System.out.println("Product ID:" + pid);
		ArrayList<ShopCart> li = (ArrayList<ShopCart>) session.getAttribute("mycart");
		ListIterator<ShopCart> lit = (ListIterator<ShopCart>) li.listIterator();
		while (lit.hasNext()) {
			ShopCart d = lit.next();
			if (d.getpId() == pid) {
				d.setQty(qty);
				d.setTotal(d.getQty() * d.getPrice());
				lit.set(d);
				break;
			}

		}

		m.addAttribute("cartitm", li);
		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(li)));
		return "CartPage";

	}

	public double getGrandTotal(ArrayList<ShopCart> cd) {
		ListIterator<ShopCart> itr = cd.listIterator();
		double grandtotal = 0;
		while (itr.hasNext()) {
			ShopCart cd1 = (ShopCart) itr.next();
			grandtotal = grandtotal + (cd1.getQty() * cd1.getPrice());

		}
		return grandtotal;
	}

	@RequestMapping(value = "/PaymentPage")
	public ModelAndView makePayment(HttpSession session) {
		ArrayList<ShopCart> shoList = (ArrayList<ShopCart>) session.getAttribute("mycart");
		ModelAndView m = new ModelAndView("PaymentPage", "ShopCart", new ShopCart());
		session.setAttribute("grandtotal", String.valueOf(getGrandTotal(shoList)));
		return m;

	}
	
	@RequestMapping("/Thanks")
	public String showThanks()
	{	
		
		return "Thanks";	
	}
	
	/*@RequestMapping(value = "/Thanku", method = RequestMethod.POST)
	public ModelAndView Thanku(HttpSession session, HttpServletRequest request) {
		ArrayList<ShopCart> li = (ArrayList<ShopCart>) session.getAttribute("mycart");
		UserDetail obj = userObj.display((String) session.getAttribute("user"));
		String email = obj.getEmail();
		String phon = obj.getPhone();
		String addr = obj.getAddress();
		String user = obj.getCustName();

		String fullAddress = user + "\t" + addr + "\t" + phon;
		OrderDetails d = new OrderDetails();

		d.setPaymentMode("Debit Card");
		d.setUserId(session.getAttribute("user").toString());
		d.setOrderDate(new Date());
		d.setOrderStatus("processing");

		String f = session.getAttribute("grandtotal").toString();

		d.setGrandTotal(Integer.valueOf(f));
		d.setAddress(fullAddress);

		orderDao.saveOrder(d);
		System.out.print("Order saved");
		int ordId = d.getOrderId();

		for (ShopCart shop : li) {
			shop.setOrderId(ordId);
			cartDao.saveCart(shop);
			System.out.print("Cart detail saved");

		}

		String data = orderDao.getOrderDetail(d.getOrderId());
		ModelAndView v = new ModelAndView("ThankYouFinaly", "OrderDetail", new OrderDetails());
		v.addObject("data", data);
		System.out.println(data);
		return v;

	}
*/
}
