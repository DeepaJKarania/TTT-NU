package com.shoes.model;

public class Contact {

	
	
}
